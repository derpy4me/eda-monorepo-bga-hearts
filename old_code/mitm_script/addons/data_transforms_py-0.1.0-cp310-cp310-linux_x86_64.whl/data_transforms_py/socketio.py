from typing import Any
import json

from data_transforms_py.transform import socketio_to_json as rs_socketio_to_json
from data_transforms_py.transform import socketio_to_msgpack as rs_socketio_to_msgpack


def socketio_to_json(socketio_message: bytes) -> str:
    return rs_socketio_to_json(socketio_message)


def socketio_to_msgpack(socketio_message: bytes) -> bytes:
    return rs_socketio_to_msgpack(socketio_message)


def socketio_to_dict(socketio_message: bytes) -> dict[str, Any]:
    return json.loads(rs_socketio_to_json(socketio_message))


__all__ = ["socketio_to_json", "socketio_to_msgpack", "socketio_to_dict"]
